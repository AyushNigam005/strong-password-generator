This folder contains Kiro metadata required for AI For Bharat Week 1 Submission.
Project: Strong Password Generator
Author: Ayush Nigam
Note: Do NOT delete this folder. Keep it in the root of the repository.
